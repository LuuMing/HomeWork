#include<iostream>
using namespace std;
int main()
{
	istream &read(char *buffer , int len);
	int array[] = { 100,200,300};
	read((char*)array, sizeof(array) );
	
}
