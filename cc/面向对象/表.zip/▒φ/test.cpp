#include <iostream>
#include<string.h>
using namespace std;
int main()
{
	int * a = new int [2];
	int * b = new int [2];
   a[0] = 1;
   a[1] = 2;
   b[0] =1;
   b[1] = 1;
	cout <<memcmp(a ,b ,sizeof(int)*2 );

}
