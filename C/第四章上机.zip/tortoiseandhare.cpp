
// tortoiseandhare.cpp
#include <iostream>

using std::cout;
using std::endl;

#include <cstdlib>

#include <ctime>

#include <iomanip>

using std::setw;

const int RACE_END = 70;
void printCurrentPositions(int bunnyPtr,int snapperPtr);
void moveHare(int & HarePtr);
void  moveTortoise(int & turtlePtr);
int main()
{
   int tortoise = 1, hare = 1, timer = 0;   

   srand( time( 0 ) );

   cout << "ON YOUR MARK, GET SET\nBANG               !!!!"
        << "\nAND THEY�RE OFF    !!!!\n";
   
   while ( tortoise != RACE_END && hare != RACE_END ) {
    	moveTortoise(tortoise);
    	moveHare(hare);
    	printCurrentPositions(hare,tortoise);
        ++timer;
   }
   if ( tortoise >= hare )
      cout << "\nTORTOISE WINS!!! YAY!!!\n";
   else
      cout << "Hare wins. Yuch.\n";

   cout << "TIME ELAPSED = " << timer << " seconds" << endl;
   return 0;
}

void  moveTortoise(int &turtlePtr)
{
   int x = 1 + rand() % 10;

   if ( x >= 1 && x <= 5 )        
      turtlePtr += 3;
   else if ( x == 6 || x == 7 )   
      turtlePtr -= 6;
   else                           
      ++( turtlePtr );
   if ( turtlePtr < 1 )
      turtlePtr = 1;
   else if ( turtlePtr > RACE_END )
      turtlePtr = RACE_END;
}

void moveHare(int & HarePtr)
{
	int x = 1 + rand() % 10;
    if ( x == 1 || x == 2 )        
    			;
    else if ( x == 3 || x ==4 )   
      HarePtr += 9;
    else if ( x == 5 )   
      HarePtr -= 12;
    else if(x==6||x==7||x==8	)                       
      HarePtr+=1;
    else if(x==9||x==10)                     
      HarePtr-=2;
   
    else if ( HarePtr > RACE_END )
      HarePtr = RACE_END;
}
void printCurrentPositions(int bunnyPtr,int snapperPtr)
{
   if ( bunnyPtr == snapperPtr ) 
      cout << setw( bunnyPtr ) << "OUCH!!!";      
   else if ( bunnyPtr < snapperPtr ) 
      cout << setw( bunnyPtr ) << "H" 
           << setw( snapperPtr - bunnyPtr ) << "T";
   else
      cout << setw( snapperPtr ) << "T" 
           << setw( bunnyPtr - snapperPtr ) << "H";
   cout << "\n";
}


/**************************************************************************
 * (C) Copyright 2002 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
