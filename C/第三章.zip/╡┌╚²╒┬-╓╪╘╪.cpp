#include<iostream>
#include<cstdlib>
using namespace std;

void sort(int a,int b)
{
	if(a>b)
	cout<<a<<' '<<b;
	else
	cout<<b<<' '<<a;
}
void sort(int a,int b,int c)
{
	if(a>b)
	{
		if(b>c)
		{
			cout<<a<<' '<<b<<' '<<c;
		}
		else if(a<c)
		{
			cout<<c<<' '<<a<<' '<<b;
		}
		else 
			cout<<a<<' '<<c<<' '<<b;
	}
	else
	{//b>a 
		if(c>b)
			cout<<c<<' '<<b<<' '<<a;
		else if(a>c)
			cout<<b<<' '<<a<<' '<<c;
		else
			cout<<b<<' '<<c<<' '<<a;
	}

}

int main()
{
	int a=1;
	int b=2;
	int c=3;
	cout<<"a,b="<<a<<' '<<b<<endl;
	cout<<"sort(a,b)=";
	sort(a,b);
	cout<<endl;
	cout<<"sort(a,b,c)=";
	sort(a,b,c);
	cout<<endl;
} 
