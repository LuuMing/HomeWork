#include<iostream>
using namespace std;
double le(int n,double x);
int main()
{
cout<<"P5(1.4)="<<le(5,1.4);	
} 
double le(int n,double x)
{
	if(n==0)
		return 1;
	if(n==1)
		return x;
	else return ((2*n-1)*le(n-1,x)-(n-1)*le(n-2,x))/n;
}
