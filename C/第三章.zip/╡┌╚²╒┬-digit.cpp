#include<iostream>
#include<string.h>
using namespace std;
char digit(string num,int k);

int main()
{
	
	int k=0;
	string num;
	cin>>num>>k;
	cout<<digit(num,k);	
}

char digit(string num,int k)
{
	if(k>num.length() )
		return '0';
	else
		return num[k-1];
}
