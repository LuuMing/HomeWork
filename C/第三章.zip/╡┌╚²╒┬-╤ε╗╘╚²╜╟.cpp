#include <iostream>
#include <iomanip>
using namespace std ;
#define N 100
int main()
{
    int a[N][N]={{1},{1,1}};
    int i,j,n;
 
    cout << "input n: "; 
    do { cin >> n; }while(n>=N); 
    for(i=2;i<n;i++)
    {
        a[i][0]=1;
        a[i][i]=1;
        for( j=1;j<i;j++ )
            a[i][j]=a[i-1][j-1]+a[i-1][j];
    }
 
    for( i=0;i<n;i++ )
    {
        for( j=0;j<n-i-1;j++ ) 
            cout << setw(3) << " " ;
        for( j=0;j<=i;j++ )
            cout << setw(6) << a[i][j] ;
        cout<<endl;
    }
}
